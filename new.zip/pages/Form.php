
<?php
    if(isset($_POST['batchno'])){
        $batchno = $_POST['batchno'];
       } else {
    $BatchNo = "081";
        }
        if(isset($_POST['targetdevice'])){
            $targetdevice = $_POST['targetdevice']; 
          }else{
            $targetdevice = 1; 
           }           
            if(isset($_POST['qty'])){
                $qty = $_POST['qty']; 
              }else{
                $qty = 1; 

             }
                if(isset($_POST['eventdetail'])){
                    $eventdetail = $_POST['eventdetail']; 
                  }else{
                    $eventdetail = "1"; 
                }
                include 'config.php';

                // Check connection
                if (!$conn) {
                    die("Connection failed: " . mysqli_connect_error());
                }
                // Check connection
                if (!$conn) {
                    die("Connection failed: " . mysqli_connect_error());
                }
                 else {
		       $stmt = $conn->prepare("insert into printings(batchno, targetdevice, qty, eventdetail) values(?, ?, ?, ?)");
		       $stmt->bind_param("iiis", $batchno, $targetdevice, $qty, $eventdetail);
		       $execval = $stmt->execute();
		       echo $execval;

		       $stmt->close();
		      $conn->close();
	}
?>