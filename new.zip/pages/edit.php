<!DOCTYPE html>
<html>
<head>
    <title>Edit Item</title>
    <script>
        function confirmSave() {
            return confirm("Are you sure you want to save the changes?");
        }
    </script>
</head>
<body>
    <?php
    // Step 1: Include the config file
    include 'config.php';

    // Step 2: Establish a database connection
    $conn = new mysqli($host, $username, $password, $database);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Step 3: Retrieve the item details based on the index
    if (isset($_GET['index'])) {
        $index = $_GET['index'];
        $sql = "SELECT `index`, item, inventory, availability FROM inventory WHERE `index`='$index'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $item = $row['item'];
            $inventory = $row['inventory'];
            $availability = $row['availability'];
        }
    }

    // Step 4: Close the database connection
    $conn->close();
    ?>
    
    <h2>Edit Item</h2>
    <form method="post" action="save.php">
        <input type="hidden" name="index" value="<?php echo $index; ?>">
        <label>Item:</label>
        <input type="text" name="item" value="<?php echo $item; ?>"><br><br>
        <label>Inventory:</label>
        <input type="text" name="inventory" value="<?php echo $inventory; ?>"><br><br>
        <label>Availability:</label>
        <input type="text" name="availability" value="<?php echo $availability; ?>"><br><br>
        <input type="submit" value="Save" onclick="return confirmSave();">
    </form>
    <br>
    <a href="index.php">Go back</a>
</body>
</html>
