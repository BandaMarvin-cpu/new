-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 20, 2023 at 11:46 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.0.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `airqo`
--

-- --------------------------------------------------------

--
-- Table structure for table `activities`
--

CREATE TABLE `activities` (
  `id` int(10) NOT NULL,
  `activity` text NOT NULL,
  `duration` int(40) NOT NULL,
  `notes` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `activities`
--

INSERT INTO `activities` (`id`, `activity`, `duration`, `notes`) VALUES
(1, '3Dprinting', 10, 'Pole-mounts\r\nCasings\r\nBrackets'),
(2, 'PCBPrinting', 0, 'Phase1(All ThroughHole)\r\nPhase2(All SMD)\r\nPhase3(All tunning)'),
(3, 'PreDeploymentAnalysis', 10, 'UploadingCode\r\nNetConfiguringaration\r\nTesting\r\nCalibration'),
(4, 'MonitorAssembly', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `alldevices`
--

CREATE TABLE `alldevices` (
  `name` varchar(102) DEFAULT NULL,
  `ChannelNomber` varchar(22) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `alldevices`
--

INSERT INTO `alldevices` (`name`, `ChannelNomber`) VALUES
('long_name', 'device_number'),
('Airqo_G5110', '1888889'),
('Airqo_G587', '1844514'),
('Airqo_G584', '1844510'),
('Airqo_G581', '1752876'),
('Airqo_G580', '1752875'),
('AirQo_G576', '1739629'),
('AirQo_G574', '1739561'),
('AirQo_G573', '1739560'),
('AirQo_G572', '1739559'),
('AirQo_G571', '1739558'),
('AirQo_G556', '1651882'),
('AirQo_G559', '1651885'),
('AirQo_G562', '1651888'),
('AirQo_G563', '1651889'),
('AirQo_G564', '1651890'),
('AirQo_G565', '1651891'),
('AirQo_G566', '1651892'),
('AirQo_G567', '1651895'),
('AirQo_G568', '1651896'),
('AirQo_G569', '1651898'),
('AirQo_G570', '1651900'),
('AirQo_G553', '1606123'),
('AirQo_G551', '1606121'),
('AirQo_G550', '1606120'),
('AirQo_G549', '1606119'),
('AirQo_G548', '1606118'),
('AirQo_G547', '1575544'),
('AirQo_G546', '1575543'),
('AirQo_G545', '1575542'),
('AirQo_G544', '1575540'),
('AirQo_G543', '1575539'),
('AirQo_G542', '1575537'),
('AirQo_G538', '1575533'),
('AIRQO-95 UNIT ACTIVE', '1014692'),
('AIRQO-100 UNIT ACTIVE', '1014698'),
('AIRQO-G536 UNIT ACTIVE', '1429567'),
('AIRQO-G532 UNIT ACTIVE', '1379965'),
('AIRQO-G533 UNIT ACTIVE', '1379966'),
('AIRQO-G534 UNIT ACTIVE', '1379967'),
('AIRQO-G535 UNIT ACTIVE', '1379969'),
('AIRQO-G530 UNIT ACTIVE', '1375499'),
('AIRQO-G523 UNIT ACTIVE', '1375491'),
('AIRQO-G524 UNIT ACTIVE', '1375492'),
('AIRQO-G526 UNIT ACTIVE', '1375494'),
('AIRQO-G527 UNIT ACTIVE', '1375495'),
('AIRQO-G528 UNIT ACTIVE', '1375496'),
('AIRQO-G529 UNIT ACTIVE', '1375497'),
('AIRQO-G521 UNIT ACTIVE', '1375489'),
('AIRQO-G520 UNIT ACTIVE', '1373040'),
('AIRQO-G517 UNIT ACTIVE', '1373037'),
('AIRQO-G518 UNIT ACTIVE', '1373038'),
('AIRQO-G519 UNIT ACTIVE', '1373039'),
('AIRQO-G516 UNIT ACTIVE', '1373036'),
('AIRQO-G515 UNIT ACTIVE', '1373035'),
('AIRQO-G514 UNIT ACTIVE', '1371829'),
('', 'AIRQO-G513 UNIT ACTIVE'),
('AIRQO-G506 UNIT ACTIVE', '1290042'),
('AIRQO-G505 UNIT ACTIVE', '1290041'),
('AIRQO-G502 UNIT ACTIVE', '1290038'),
('AIRQO-94 UNIT ACTIVE', '1014691'),
('AIRQO-98 UNIT ACTIVE', '1014696'),
('AIRQO-G503 UNIT ACTIVE', '1290039'),
('AIRQO-G501 UNIT ACTIVE', '1290037'),
('AIRQO-G512 UNIT ACTIVE', '1351546'),
('AIRQO-G511 UNIT ACTIVE', '1351544'),
('AIRQO-G510 UNIT ACTIVE', '1351543'),
('AIRQO-G509 UNIT ACTIVE', '1351542'),
('AIRQO-G508 UNIT ACTIVE', '1351540'),
('AIRQO-G507 UNIT ACTIVE', '1351535'),
('AIRQO-G504 UNIT ACTIVE', '1290040'),
('AIRQO-99 UNIT ACTIVE', '1014697'),
('AIRQO-91 UNIT ACTIVE', '1014687'),
('AIRQO-92 UNIT ACTIVE', '1014688'),
('AIRQO-93 UNIT ACTIVE', '1014689'),
('AIRQO-82 UNIT ACTIVE', '967593'),
('AIRQO-83 UNIT ACTIVE', '967594'),
('AIRQO-85 UNIT ACTIVE', '967597'),
('AIRQO-86 UNIT ACTIVE', '967598'),
('AIRQO-88 UNIT ACTIVE', '967600'),
('AIRQO-71 UNIT ACTIVE', '930426'),
('AIRQO-72 UNIT ACTIVE', '930427'),
('AIRQO-78 UNIT ACTIVE', '930433'),
('AIRQO-79 UNIT ACTIVE', '930434'),
('AIRQO-64 UNIT ACTIVE', '912219'),
('AIRQO-65 UNIT ACTIVE', '912220'),
('AIRQO-66 UNIT ACTIVE', '912221'),
('AIRQO-67 UNIT ACTIVE', '912222'),
('AIRQO-68 UNIT ACTIVE', '912223'),
('AIRQO-69 UNIT ACTIVE', '912224'),
('AIRQO-70 UNIT ACTIVE', '912225'),
('AIRQO-57 UNIT ACTIVE', '870140'),
('AIRQO-58 UNIT ACTIVE', '870142'),
('AIRQO-59 UNIT ACTIVE', '870143'),
('AIRQO-60 UNIT ACTIVE', '870144'),
('AIRQO-61 UNIT ACTIVE', '870145'),
('AIRQO-63 UNIT ACTIVE', '870147'),
('AIRQO-52 UNIT ACTIVE', '832252'),
('AIRQO-53 UNIT ACTIVE', '832253'),
('AIRQO-54 UNIT ACTIVE', '832254'),
('AIRQO-45 UNIT ACTIVE', '782718'),
('AIRQO-46 UNIT ACTIVE', '782719'),
('AIRQO-47 UNIT ACTIVE', '782720'),
('AIRQO-49 UNIT ACTIVE', '782722'),
('AIRQO-WB41 UNIT ACTIVE', '755609'),
('AIRQO-43 UNIT ACTIVE', '755612'),
('AIRQO-44 UNIT ACTIVE', '755614'),
('AIRQO-WB35UNIT ACTIVE', '730019'),
('AIRQO-WB39 UNIT ACTIVE', '737276'),
('AIRQO-40 UNIT ACTIVE', '737278'),
('AIRQO-33 UNIT ACTIVE', '730015'),
('AIRQO-WB29 UNIT ACTIVE', '718028'),
('AIRQO-WB20 UNIT ACTIVE', '689749'),
('AIRQO-WB22 UNIT ACTIVE', '689752'),
('AIRQO-WB23 UNIT ACTIVE', '689753'),
('AIRQO-WB24 UNIT ACTIVE', '689756'),
('AIRQO-WB26 UNIT ACTIVE', '689761'),
('AIRQO-WB6 UNIT ACTIVE', '675801'),
('AIRQO-WB9 UNIT ACTIVE', '675991'),
('AIRQO-WB10 UNIT ACTIVE', '676000');

-- --------------------------------------------------------

--
-- Table structure for table `batches`
--

CREATE TABLE `batches` (
  `id` int(30) NOT NULL,
  `batchno` varchar(50) NOT NULL,
  `datetime` date NOT NULL,
  `qty` int(10) NOT NULL,
  `state` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `batches`
--

INSERT INTO `batches` (`id`, `batchno`, `datetime`, `qty`, `state`) VALUES
(2, 'Gen5C.0/23/1', '2022-12-01', 23, 'Deployed'),
(3, 'Gen5AQR.C.0', '2022-11-01', 6, 'AQSpec'),
(4, 'GEN5RB.1/23/02', '2023-02-01', 23, 'Testing'),
(5, 'GEN5RB.2/23/03', '2023-03-01', 10, 'PCB_Assembly'),
(6, 'GEN5RB.2/23/04', '2023-04-01', 16, 'pcb3'),
(7, 'GEN5RB.2/23/05', '2023-05-01', 17, 'Predeploymen'),
(8, 'GEN5RB.2/23/06', '2023-06-02', 10, 'PCB_3'),
(9, 'GEN5RB.1/23/07', '2023-07-01', 10, 'PCB_3'),
(10, 'GEN5RB.2/23/010', '2023-05-01', 20, 'PCB_3');

-- --------------------------------------------------------

--
-- Table structure for table `bom`
--

CREATE TABLE `bom` (
  `id` int(2) DEFAULT NULL,
  `name` varchar(21) DEFAULT NULL,
  `q` int(2) DEFAULT NULL,
  `producer` varchar(26) DEFAULT NULL,
  `unitcost` double DEFAULT NULL,
  `totalcost` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `bom`
--

INSERT INTO `bom` (`id`, `name`, `q`, `producer`, `unitcost`, `totalcost`) VALUES
(1, 'SR521 Battery Clip', 2, 'MyYoung', 0.025, 0.05),
(2, '1K', 4, 'YAGEO', 0, 0),
(3, '532610871', 2, 'MOLEX', 0.036, 0.072),
(4, '3.3V switch', 1, 'BOOMELE', 0.006, 0.006),
(5, 'LM1117IMPX-3.3/NOPB', 1, 'TI', 0.068, 0.068),
(6, '3.3V rail', 1, 'Ckmtw', 0.018, 0.018),
(7, 'GREEN', 1, '', 0, 0),
(8, 'DHT11', 1, 'Aosong (Guangzhou) Elec', 0.186, 0.186),
(9, 'UBLOX', 1, 'Ckmtw', 0.007, 0.007),
(10, 'ATMEGA 2560', 1, '', 0, 0),
(11, 'SR54L', 2, 'MOSPEC', 0.023, 0.046),
(12, 'XL4005E1', 1, 'XLSEMI', 0.109, 0.109),
(13, 'sim800l', 1, 'Ckmtw', 0.007, 0.007),
(14, '* ISP', 1, 'BOOMELE', 0.005, 0.005),
(15, 'IRF630NPBF', 2, 'IR', 0.05, 0.1),
(16, '470uF', 1, 'ROQANG', 0.006, 0.006),
(17, '16MHz', 1, 'SHIVRAM', 0, 0),
(18, '4.7uH', 2, '3L COILS', 0.031, 0.062),
(19, '20K', 3, 'Chengdu Guosheng Tech', 0.029, 0.08700000000000001),
(20, '22uF', 8, 'SAMSUNG', 0.002, 0.016),
(21, 'Vout', 1, 'BOOMELE', 0.006, 0.006),
(22, 'FP6298XR-G1', 2, 'Feeling Technology', 0.07, 0.14),
(23, '470uF', 1, 'ROQANG', 0.019, 0.019),
(24, 'Header-Male-2.54_1x5', 1, 'Ckmtw', 0.007, 0.007),
(25, 'Batter', 1, 'BOOMELE', 0.002, 0.002),
(26, 'Header-Male-2.54_1x6', 1, 'BOOMELE', 0.004, 0.004),
(27, 'Header-Male-2.54_1x10', 1, '', 0.007, 0.007),
(28, 'bme280 connectoer', 1, 'Ckmtw', 0.018, 0.018),
(29, 'Switch', 1, 'BOOMELE', 0.006, 0.006),
(30, 'Davis Annemometer', 1, 'BOOMELE', 0.011, 0.011),
(31, 'program Header', 1, 'Ckmtw', 0.007, 0.007),
(32, 'Header-Male-2.54_2x4', 1, 'ReliaPro', 0, 0),
(33, '47uH', 1, 'SXN', 0.093, 0.093),
(34, 'BSS138_C426569', 5, 'SLKORMICRO Elec.', 0.004, 0.02),
(35, '10K', 16, 'YAGEO', 0, 0),
(36, 'ZL-YDW1207-4005PA-7.5', 1, 'ZLFY', 0.018, 0.018),
(37, '470uF', 3, 'Nantong Jianghai Capacitor', 0.016, 0.048),
(38, 'DC005-2.0MM', 1, 'SOFNG', 0.027, 0.027),
(39, 'HY19P03D', 1, 'HUAYI(华羿微)', 0.077, 0.077),
(40, '100K', 1, 'WALSIN', 0, 0),
(41, 'DS3231MZ+', 1, 'MAXIM(美信)', 0.822, 0.822),
(42, '73.2K', 3, 'UniOhm', 0, 0),
(43, 'SHT25', 1, 'Sensirion', 1.505, 1.505),
(44, '4.7K', 4, 'Huaxin S&T', 0, 0),
(45, '100nF', 1, 'Holy Stone Enterprise', 0.001, 0.001),
(46, 'THD2528-11SD-GF', 1, 'THD', 0.035, 0.035),
(47, 'SK54B', 1, 'SMC', 0.028, 0.028),
(48, 'CD1206-S01575', 1, 'BOURNS', 0.006, 0.006),
(49, '1uF', 3, 'TAIYO YUDEN', 0.004, 0.012),
(50, '33nF', 1, 'Huaxin S&T', 0, 0),
(51, '22pF', 3, 'Murata Electronics', 0.004, 0.012),
(52, '2K', 2, 'YAGEO', 0, 0),
(53, '10K', 2, 'UniOhm', 0, 0),
(54, '100nF', 4, 'FH', 0, 0),
(55, '4.7K', 1, 'Ever Ohms Tech', 0.001, 0.001),
(56, '59K', 1, 'UniOhm', 0, 0),
(57, 'GsmVccOut', 1, 'BOOMELE', 0.006, 0.006),
(NULL, 'uy', 5, 'mn', 10, 0);

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `index` varchar(5) NOT NULL,
  `item` varchar(50) NOT NULL,
  `unit` varchar(15) NOT NULL,
  `stockIn` int(14) NOT NULL,
  `stockout` int(15) NOT NULL,
  `inventory` varchar(9) NOT NULL,
  `availability` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`index`, `item`, `unit`, `stockIn`, `stockout`, `inventory`, `availability`) VALUES
('5', 'GSM MODULES(SIM7600G)', 'unit', 2, 0, '2', 1),
('7', ' CONVERTOR PROTOCAL(RS485 TO TTL)', 'unit', 0, 0, '0', 0),
('8', 'MICRO SD CARD MODULES', 'unit', 77, 7, '70', 91),
('9', 'MICROCONTROLLERS(MCU\'S2560)', 'unit', 44, 0, '44', 100),
('10', 'PCB\'S', 'unit', 199, 30, '169', 85),
('11', 'SOLDER PASTE', 'unit', 79, 0, '79', 100),
('12', 'SOLDER WIRE ROLL', 'unit', 3, 0, '3', 100),
('13', 'SOLDER FLUX', 'unit', 6, 0, '6', 100),
('14', 'SCREWS', 'unit', 0, 0, '0', 0),
('15', 'BOLTS AND SCREWS', 'unit', 0, 0, '0', 0),
('16', 'BATTERIES(SINGULAR HOLDER)', 'unit', 324, 0, '324', 100),
('17', 'BATTERIES HOLDER(A SET OF 3PCS)', 'unit', 86, 13, '73', 85),
('18', '', 'unit', 0, 0, '0', 0),
('19', '470uH INDUCTOR', 'unit', 100, 0, '100', 100),
('20', 'ISP PIN HEADERS MALE', 'unit', 100, 0, '100', 100),
('21', '3PIN MALE HEADERS', 'unit', 200, 0, '200', 100),
('22', 'SS54L 40V, 440mV@5A, 5A SCHOTTKY DIODE', 'unit', 200, 0, '200', 100),
('23', '33nF,50V CAP', 'unit', 200, 0, '200', 100),
('24', 'SOLDER WICK', 'unit', 5, 0, '5', 100),
('25', ' SD CARDS', 'unit', 202, 72, '130', 64),
('26', 'FEMALE JUMPER WIRES', 'unit', 369, 0, '369', 100),
('27', 'MALE JUMPER WIRES', 'unit', 238, 0, '238', 100),
('28', 'BUZZER', 'unit', 118, 0, '118', 100),
('29', 'FINISHED MONITORS', 'unit', 24, 0, '24', 100),
('30', 'SOLAR PANELS', 'unit', 198, 65, '133', 67),
('31', 'POTENTIAL DIVIDERS', 'unit', 753, 0, '753', 100),
('32', ' PM SENSOR FEMALE SOCKETS', 'unit', 235, 0, '235', 100),
('33', 'SMD USB CONNECTORS', 'unit', 198, 0, '198', 100),
('34', 'CIMOS HOLDER', 'unit', 85, 0, '85', 100),
('35', 'MOSFETS(IRF630N)', 'unit', 449, 0, '449', 10),
('36', 'DC POWER JACKS', 'unit', 282, 0, '282', 100),
('37', 'REV C PCBS', 'unit', 25, 0, '25', 100),
('38', 'BAM LOGGER PCB', 'unit', 3, 0, '3', 100),
('40', 'PETG ROLLS', 'unit', 14, 12, '2', 14),
('41', 'REV B AIRQO MONITOR UNITS', 'unit', 22, 0, '22', 100),
('42', 'REV C AIRQO MONITOR UNITS', 'unit', 16, 0, '16', 100),
('43', 'LITHIUM CYLINDRICAL BATTERY(18560)', 'unit', 56, 56, '0', 0),
('44', 'MPN, SHT25,DFN-6 Temperature and Humidity sensor', 'unit', 20, 0, '20', 100),
('45', 'MPN,LM11 17IMPX-3.3/NOPB 800mA 1,2v@(800mA)', 'unit', 100, 0, '100', 100),
('46', 'CD4148WP 75V+150 C @Tj 400mW 1.25V @100mA 5milA', 'unit', 200, 0, '200', 100),
('47', '2K Ohm resistors RC0603', 'unit', 500, 0, '500', 100),
('48', 'SK54B DIODE', 'unit', 100, 0, '100', 100),
('49', 'XL4005E1 STEP-DOWN REGULATOR', 'unit', 100, 0, '100', 100),
('50', '100nF CAPACITOR', 'unit', 500, 0, '500', 100),
('51', '1uF CAPACITOR', 'unit', 400, 0, '400', 100),
('52', 'FP6298XR-G1 BOOST CHIP', 'unit', 150, 0, '150', 100),
('53', 'IRF7416TRPBF SOP-8 MOSFET', 'unit', 100, 0, '100', 100),
('54', 'BSS138 50V,220mA CHIP', 'unit', 100, 0, '100', 100),
('55', 'NCD0805 Y1 LED ', 'unit', 200, 0, '200', 100),
('56', '1K Ohm resistors', 'unit', 500, 0, '500', 100),
('57', 'INDUCTORS(SNR8040K-4R7N 4A 4.7uH)', 'unit', 200, 0, '200', 100),
('58', 'RVTIV471M1010(35V,470uF) CAP', 'unit', 100, 0, '100', 100),
('59', '73K Ohm resistors', 'unit', 700, 0, '700', 100),
('60', '4.7k Ohm resistors', 'unit', 700, 0, '700', 100),
('61', '100k Ohm resistors', 'unit', 500, 0, '500', 100),
('62', '22uF CAP', 'unit', 500, 0, '500', 100),
('63', '100nF CAPACITOR', 'unit', 500, 0, '500', 100),
('64', '22pF CAP', 'unit', 500, 0, '500', 100),
('65', 'CRYSTAL OSCILLATORS 16MHz', 'unit', 100, 0, '100', 100),
('66', '10v,470uF CAP', 'unit', 200, 0, '200', 100),
('68', 'GPS MODULES (BLOX NEO-6M-G-001#GY-GPS6MV2)', 'unit', 133, 29, '104', 78),
('70', '59k Ohm resistors', 'unit', 500, 0, '500', 100),
('69', '10k Ohm resistors', 'unit', 500, 0, '500', 100),
('71', 'clock chips (DS3231M 1124A1 487AA)', 'unit', 50, 0, '50', 100),
('72', 'LITHIUM-ION POLYMER', 'unit', 50, 10, '40', 80),
('73', 'ORIGINAL PRUSA i3 MK3 BY JOSEF PRUSA PRINTER', 'unit', 3, 0, '3', 100),
('74', 'MAKERGEAR', 'unit', 1, 0, '1', 100),
('75', 'APC(UPS) POWER SUPPLY UNIT BACKUP', 'unit', 1, 0, '1', 100),
('76', 'SUNKKO 709A PULSE SPOT WELDING & SOLDERING MACHINE', 'unit', 1, 0, '1', 100),
('77', 'DDS SIGNAL GENERATOR/COUNTER', 'unit', 1, 0, '1', 100),
('78', 'XDS3202E WON OSCILLOSCOPE', 'unit', 1, 0, '1', 100),
('79', 'SMD MAGNIFYING GLASSES EQUIPMENT', 'unit', 2, 0, '2', 100),
('80', 'DAZHENG DC POWER SUPPLY PS-303D', 'unit', 1, 0, '1', 100),
('81', 'DC POWER SUPPLY 0-30V 0-5A(YIHUA 3005D)', 'unit', 1, 0, '1', 100),
('82', 'JACKLY 702L REWORK STATION', 'unit', 1, 0, '1', 100),
('83', 'YAXUN SMD REWORK SOLDERING STATION', 'unit', 1, 0, '1', 100),
('84', 'DIGITAL MULTIMETERS', 'unit', 3, 0, '3', 100),
('85', 'SOLDERING GUNS', 'unit', 3, 0, '3', 100),
('86', 'UPSPRINT ELECTRIC BLOWER', 'unit', 1, 0, '1', 100),
('87', 'INSULATING ELECTRIC TAPE', 'unit', 30, 0, '30', 100);

-- --------------------------------------------------------

--
-- Table structure for table `links`
--

CREATE TABLE `links` (
  `index` int(12) NOT NULL,
  `link` text NOT NULL,
  `name` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `links`
--

INSERT INTO `links` (`index`, `link`, `name`) VALUES
(1, 'https://drive.google.com/drive/folders/1a9siukHVhtkvpvf_4p1NAz7XkSasp58v', 'RnD'),
(2, 'https://drive.google.com/drive/folders/1nYwYO5C9jpumsK32Vnd9BEpziwcSpaH1', 'firmware'),
(3, 'https://docs.google.com/spreadsheets/d/19-eejH4yMmRCgYCCzARUaHqysg0L83dgGIAxZqPuyfg/edit#gid=1932460348', 'activedevices'),
(4, 'https://drive.google.com/drive/folders/0AAATgqqed5REUk9PVA', 'drive');

-- --------------------------------------------------------

--
-- Table structure for table `monitorassembly`
--

CREATE TABLE `monitorassembly` (
  `index` int(10) NOT NULL,
  `batchno` varchar(30) NOT NULL,
  `targetdevice` varchar(30) NOT NULL,
  `qty` int(20) NOT NULL,
  `datetime` date NOT NULL,
  `eventdetail` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `monitorassembly`
--

INSERT INTO `monitorassembly` (`index`, `batchno`, `targetdevice`, `qty`, `datetime`, `eventdetail`) VALUES
(0, 'GEN5RB.1/23/01', 'Gen5Rb.1', 10, '2023-02-01', 'DHT replacements');

-- --------------------------------------------------------

--
-- Table structure for table `pcb assembly phases`
--

CREATE TABLE `pcb assembly phases` (
  `index` int(30) NOT NULL,
  `phase` int(30) NOT NULL,
  `notes` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pcb assembly phases`
--

INSERT INTO `pcb assembly phases` (`index`, `phase`, `notes`) VALUES
(1, 1, 'All SMD'),
(2, 2, 'ALL THT'),
(3, 3, 'All Tunnings');

-- --------------------------------------------------------

--
-- Table structure for table `pcbs`
--

CREATE TABLE `pcbs` (
  `index` int(10) NOT NULL,
  `batchno` varchar(30) NOT NULL,
  `targetdevice` varchar(30) NOT NULL,
  `qty` int(20) NOT NULL,
  `datetime` date NOT NULL,
  `phase` varchar(10) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pcbs`
--

INSERT INTO `pcbs` (`index`, `batchno`, `targetdevice`, `qty`, `datetime`, `phase`) VALUES
(0, 'GEN5RB.2/23/04', 'GEN5RB.2', 16, '2023-03-27', '3');

-- --------------------------------------------------------

--
-- Table structure for table `predeploymentanalysis`
--

CREATE TABLE `predeploymentanalysis` (
  `index` int(10) NOT NULL,
  `batchno` varchar(30) NOT NULL,
  `targetdevice` varchar(30) NOT NULL,
  `qty` int(20) NOT NULL,
  `datetime` date NOT NULL,
  `eventdetail` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `predeploymentanalysis`
--

INSERT INTO `predeploymentanalysis` (`index`, `batchno`, `targetdevice`, `qty`, `datetime`, `eventdetail`) VALUES
(0, 'GEN5RB.1/23/01', 'Gen5Rb.1', 10, '2023-01-10', '');

-- --------------------------------------------------------

--
-- Table structure for table `printings`
--

CREATE TABLE `printings` (
  `index` int(10) NOT NULL,
  `batchno` varchar(30) NOT NULL,
  `targetdevice` varchar(30) NOT NULL,
  `specificproduct` text NOT NULL,
  `qty` int(20) NOT NULL,
  `datetime` date NOT NULL,
  `eventdetail` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `printings`
--

INSERT INTO `printings` (`index`, `batchno`, `targetdevice`, `specificproduct`, `qty`, `datetime`, `eventdetail`) VALUES
(1, 'GEN5RB.1/23/01', 'Gen5Rb.1', 'Pole-Mount', 2, '2023-01-03', 'Pole-Mounts under casings'),
(2, 'GEN5RB.1/23/01', 'Gen5Rb.1', 'BottomCovers', 5, '2023-01-04', 'Bottom Covers\r\nAnd Pole Mounts'),
(3, 'GEN5RB.1/23/01', 'Gen5Rb.1', 'TopCover', 4, '2023-01-05', 'TopCovers'),
(4, 'GEN5RB.1/23/01', 'Gen5Rb.1', 'BottomCasings', 3, '2023-01-06', 'BottomCasings'),
(5, 'GEN5RB.1/23/01', 'Gen5Rb.1', 'Bracket', 5, '2023-01-09', 'Brackets'),
(6, 'GEN5RB.1/23/01', 'Gen5Rb.1', 'PoleMounts', 6, '2023-01-10', 'PoleMounts'),
(7, 'GEN5RB.1/23/01', 'Gen5Rb.1', 'Bases', 3, '2023-01-17', '3 bases'),
(8, 'GEN5RB.1/23/01', 'Gen5Rb.1', 'TopCovers', 9, '2023-01-17', '9 topCovers'),
(9, 'GEN5RB.1/23/01', 'Gen5Rb.1', 'PoleMounts', 2, '2023-01-17', '2 poleMounts'),
(10, 'GEN5RB.1/23/01', 'Gen5Rb.1', 'PM sensors', 14, '2023-01-17', '14 Pm sensors'),
(11, 'GEN5RB.1/23/01', 'Gen5Rb.1', 'TopCovers', 9, '2023-01-16', '9 topcovers'),
(12, 'GEN5RB.1/23/01', 'Gen5Rb.1', 'Bases', 6, '2023-01-16', '6 bases'),
(13, 'GEN5RB.1/23/01', 'Gen5Rb.1', 'SensorHolders', 6, '2023-01-18', '6 pm sensor holders'),
(14, 'GEN5RB.1/23/01', 'Gen5Rb.1', 'Bases', 6, '2023-01-18', '6 Bases'),
(15, 'GEN5RB.1/23/01', 'Gen5Rb.1', 'Covers', 3, '2023-01-18', '3 covers'),
(16, 'GEN5RB.1/23/01', 'Gen5Rb.1', 'Solar Mounts', 10, '2023-01-11', '10 pm sensor holders '),
(17, 'GEN5RB.1/23/01', 'Gen5Rb.1', 'Solar mounts', 1, '2023-01-11', 'solar mount'),
(18, 'GEN5RB.1/23/01', 'Gen5Rb.1', 'Enclosure', 6, '2023-01-13', '6 tops and 6 bases making 6 full monitor casings'),
(66, '81', '1', '', 1, '0000-00-00', '1'),
(67, '81', '1', '', 1, '0000-00-00', '1'),
(68, '81', '1', '', 1, '0000-00-00', '1'),
(69, '81', '1', '', 1, '0000-00-00', '1'),
(70, '81', '1', '', 1, '0000-00-00', '1'),
(71, '81', '1', '', 1, '0000-00-00', '1'),
(72, '81', '1', '', 1, '0000-00-00', '1'),
(73, '81', '1', '', 1, '0000-00-00', '1'),
(74, '81', '1', '', 1, '0000-00-00', '1'),
(75, '81', '1', '', 1, '0000-00-00', '1'),
(76, '81', '1', '', 1, '0000-00-00', '1'),
(77, '81', '1', '', 1, '0000-00-00', '1'),
(78, '81', '1', '', 1, '0000-00-00', '1'),
(79, '81', '1', '', 1, '0000-00-00', '1'),
(80, '81', '1', '', 1, '0000-00-00', '1'),
(81, '81', '1', '', 1, '0000-00-00', '1'),
(82, '81', '1', '', 1, '0000-00-00', '1'),
(83, '81', '1', '', 1, '0000-00-00', '1'),
(84, '81', '1', '', 1, '0000-00-00', '1'),
(85, '81', '1', '', 1, '0000-00-00', '1'),
(86, '81', '1', '', 1, '0000-00-00', '1'),
(87, '81', '1', '', 1, '0000-00-00', '1'),
(88, '81', '1', '', 1, '0000-00-00', '1'),
(89, '81', '1', '', 1, '0000-00-00', '1'),
(90, '81', '1', '', 1, '0000-00-00', '1');

-- --------------------------------------------------------

--
-- Table structure for table `targets`
--

CREATE TABLE `targets` (
  `index` int(11) NOT NULL,
  `output` text NOT NULL,
  `datetime` text DEFAULT NULL,
  `Status` text NOT NULL,
  `notes` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `targets`
--

INSERT INTO `targets` (`index`, `output`, `datetime`, `Status`, `notes`) VALUES
(1, '80 dones', 'quater1', 'Done', 'Quarter target of 80 monitors d\r\none'),
(2, '60 Done', 'quater2', 'InProgress', ''),
(3, '300 monitors', 'Yearly', 'inProgress', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activities`
--
ALTER TABLE `activities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `batches`
--
ALTER TABLE `batches`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `links`
--
ALTER TABLE `links`
  ADD PRIMARY KEY (`index`);

--
-- Indexes for table `pcb assembly phases`
--
ALTER TABLE `pcb assembly phases`
  ADD PRIMARY KEY (`index`);

--
-- Indexes for table `printings`
--
ALTER TABLE `printings`
  ADD PRIMARY KEY (`index`);

--
-- Indexes for table `targets`
--
ALTER TABLE `targets`
  ADD PRIMARY KEY (`index`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activities`
--
ALTER TABLE `activities`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `batches`
--
ALTER TABLE `batches`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `links`
--
ALTER TABLE `links`
  MODIFY `index` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `pcb assembly phases`
--
ALTER TABLE `pcb assembly phases`
  MODIFY `index` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `printings`
--
ALTER TABLE `printings`
  MODIFY `index` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=91;

--
-- AUTO_INCREMENT for table `targets`
--
ALTER TABLE `targets`
  MODIFY `index` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
