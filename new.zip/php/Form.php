<?php
    if(isset($_POST['BatchNo'])){
        $BatchNo = $_POST['BatchNo'];
       } else {
    $BatchNo = "081";
        }
        if(isset($_POST['TargetDevice'])){
            $TargetDevice = $_POST['TargetDevice']; 
          }else{
            $TargetDevice = 1; 
           }           
            if(isset($_POST['Qty'])){
                $Qty = $_POST['Qty']; 
              }else{
                $Qty = 1; 

             }
                if(isset($_POST['EventDetail'])){
                    $EventDetail = $_POST['EventDetail']; 
                  }else{
                    $EventDetail = "1"; 
                }
                $conn = new mysqli('localhost','root','','Airqo');
	            if($conn->connect_error){
		        echo "$conn->connect_error";
		        die("Connection Failed : ". $conn->connect_error);
	           } else {
		       $stmt = $conn->prepare("insert into Printings(BatchNo, TargetDevice, Qty, EventDetail) values(?, ?, ?, ?)");
		       $stmt->bind_param("iiis", $BatchNo, $TargetDevice, $Qty, $EventDetail);
		       $execval = $stmt->execute();
		       echo $execval;

		       $stmt->close();
		      $conn->close();
	}
?>